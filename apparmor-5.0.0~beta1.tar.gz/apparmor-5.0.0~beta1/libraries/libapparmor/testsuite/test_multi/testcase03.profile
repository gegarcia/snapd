/bin/ping {
  capability setuid,

}
