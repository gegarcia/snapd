/usr/bin/xxx {
}
